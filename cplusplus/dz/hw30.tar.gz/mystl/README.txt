Название: my standart tool library (сокращенно mystl)
Создатель: Андрей
Описание: Библиотека для облегчения работы
https://fex.net/s/fca3f8s
