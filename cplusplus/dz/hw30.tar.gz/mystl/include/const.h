#pragma once
#define LIB_VERSION 0.2
#define PI	3.14159265358979323846
const int COL = 5; // обозначено константой ибо в виде макроса не работает некоторые вещи
const char eng_alphabet[52]{
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'Y', 'W', 'X', 'Y', 'Z',
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'y', 'w', 'x', 'y', 'z'
};