#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    /*
        Дан двумерный массив размерностью 4×6.
        Заполняется случайными числами в диапазоне от -15 до 25.

        - Определить сумму элементов каждой строки и вывести справа строки.

        - Определить сумму элементов каждого столбика и вывести ниже матрицы.

        Оформить следующим образом:
        -15 2 5 -1 7 6 сумма = 4
        24 -13 10 13 -9 4 сумма = 29
        19 2 22 25 -13 -4 сумма = 51
        15 9 -14 -7 -8 15 сумма = 10
        ---------сумма по колонкам-------------
        43 0 23 30 -23 21
    */
    // srand(time(0));
    // const int ROW = 4, COL=6;
    // int arr[ROW][COL], summa=0;
    // for (int i = 0; i < ROW; i++)
    // {
    //     summa = 0;
    //     for (int j = 0; j < COL; j++)
    //     {
    //         arr[i][j] = rand() % 41 - 15;
    //         summa += arr[i][j];
    //         cout << setw(6)  << arr[i][j];
    //     }
    //     cout << " Сумма: " << summa;
    //     cout << endl;
    // }
    // cout << "---Сумма по колонкам----" << endl;
    // for (int i = 0; i < COL; i++)
    // {

    //     summa = 0;
    //     for (int j = 0; j < ROW; j++)
    //     {
    //         summa += arr[j][i];
    //     }
    //     cout << setw(6) << summa;
    // }
    // cout << endl;
    /*
        Дан двумерный массив размерностью 4×6.
        Заполняется случайными числами в диапазоне от -15 до 25.

        - Определить максимальный элемент каждой строки и вывести справа строки.
        Оформить следующим образом:

        -15 2 5 -1 7 6 max = 7
        24 -13 10 13 -9 4 max = 24
        19 2 22 25 -13 -4 max = 25
        15 9 -14 -7 -8 15 max = 15
    */
    // srand(time(0));
    // const int ROW = 4, COL = 6;
    // int arr[ROW][COL], max, max_row[ROW], max_column[COL];
    // for (int i = 0; i < ROW; i++)
    // {
    //     for (int j = 0; j < COL; j++)
    //     {
    //         arr[i][j] = rand() % 41 - 15;
    //     }
    // }

    // for (int i = 0; i < ROW; i++)
    // {
    //     max = arr[i][0];
    //     for (int j = 0; j < COL; j++)
    //     {
    //         if (arr[i][j] > max)
    //             max = arr[i][j];
    //         cout << setw(6) << arr[i][j];
    //     }
    //     max_row[i]=max;
    //     cout << " Максимум: " << max;
    //     cout << endl;
    // }
    // cout << "---Максимум по колонкам----" << endl;
    // for (int j = 0; j < COL; j++)
    // {

    //     max = arr[0][j];
    //     for (int i = 0; i < ROW; i++)
    //     {
    //         if (arr[i][j] > max)
    //             max = arr[i][j];
    //     }
    //     max_column[j]=max;
    //     cout << setw(6) << max;
    // }
    // cout <<  endl <<"Максимум по колонкам:" << endl;
    // for (int i = 0; i < COL; i++)
    // {
    //    cout << max_column[i] << "   ";
    // }
    
    // cout << endl;
    /*
        Дан двумерный массив размерностью 4 × 6.
        Заполняется случайными числами.

        - Отсортировать каждую строку матрицы в порядке возрастания. Вывести матрицу после сортировки на экран.
        - Отсортировать каждую столбец матрицы в порядке возрастания. Вывести матрицу после сортировки на экран.

        Метод сортировки - Пузырек.
    */
    srand(time(0));
    const int ROW = 4, COL = 6;
    int arr[ROW][COL], temp;
    cout << "Матрица до сортировки:" << endl;
    for (int i = 0; i < ROW; i++)
    {
        for (int j = 0; j < COL; j++)
        {
            arr[i][j] = rand() % 41 - 15;
            cout << setw(6) << arr[i][j];
        }
        cout << endl;
    }
    for (int i = 0; i < ROW; i++)
    {
        for (int j = 0; j < COL-1; j++)
        {
            for (int k = 0; k < COL-1; k++)
            {
                if(arr[i][k] > arr[i][k+1]) {
                    temp = arr[i][k];
                    arr[i][k] = arr[i][k+1];
                    arr[i][k+1]=temp;
                }
            }
            
        }
    }
    cout << "Массив после сортировки:" << endl;
    for (int i = 0; i < ROW; i++)
    {
        for (int j = 0; j < COL; j++)
        {
            cout << setw(6) <<  arr[i][j];
        }
        cout << endl;
    }
    
    



    return 0;
}