#include <iostream>
#include <iomanip>
#include "../mystl/include/templates.h"
#include "../mystl/include/lib_arr.h"
#include "../mystl/include/lib.h"
using namespace std;

long long factorial(int n) {
    int f = 1;
    for (int i = 1; i <= n; i++)
    {
        f *= i;
    }
    return f;
}

long long recursive_factorial(int N)
{
    if(N < 0) 
        return 0; 
    else if (N == 1) 
        return 1; 
    return N * recursive_factorial(N - 1); 
}

void recursive_print(int N) {
    if(N > 0)
        recursive_print(N-1);
    cout << N << "  ";
}

void recursive_reverse_print(int N) {
    cout << N << "  ";
    if(N > 0)
        recursive_reverse_print(N-1);
}

void recursive_range_print(int a,int b) {
    cout << a << "  ";
    if(a > b)
        recursive_range_print(a - 1, b);
    else if(a < b)
        recursive_range_print(a + 1, b);
}

void recursive_line(char sym, int n) {
    if(n > 1)
        recursive_line(sym,n-1);
    cout << sym;
}

void recursive_show_reversed_number(int n) {
    if(n) {
        cout << n % 10;
        recursive_show_reversed_number(n / 10);
    }
}

int recursive_summa(int n) {
    if(n == 1)
        return 1;
    return n + recursive_summa(n-1);
}

int recursive_summa_digit(int n) {
    if(n < 10)
        return n;
    return n % 10 + recursive_summa_digit(n/10);
}

int main()
{
    // const int N = 10;
    // int arr[10], index;
    // fill_it(arr,N,-5,10);
    // bubble_sort(arr,N);
    // bubble_sort(arr,N);
    // wrapper_show(arr,N);
    // index = binary_search(arr,1,N);
    // if(index != -1)
    //     cout << "Значение найденно,позиция " << index+1 << endl; 
    // else
    //     cout << "Значение не найденно" << endl;
    // Сменшать значения
    // wrapper_show(arr,N);
    // wrapper_show(arr,N);
    // mix(arr,N);
    // wrapper_show(arr,N);
    // Рекурсия - Вычисление факториала числа
    // cout << factorial(5) << endl;
    // cout << recursive_factorial(5) << endl;
    // recursive_print(5);
    // recursive_range_print(10,5);
    // cout << endl;
    // recursive_line('+',5);
    // cout << endl;
    // recursive_show_reversed_number(12345);
    // cout << endl;
    // cout << recursive_summa(5);
    // cout << endl;
    // cout << recursive_summa_digit(12345);
    // const int N = 10;
    // int arr[N];
    // fill_it(arr,N);
    // wrapper_show(arr,N);

    return 0;
}

