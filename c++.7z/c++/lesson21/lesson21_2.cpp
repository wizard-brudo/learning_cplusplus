#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    // const int ROW = 3, COL = 5;
    // int arr[ROW][COL]{-3, 5, 6, 7, 8, 53, 4242, 56, 475, 32, 12, 345, 67, 86, 133}, summa = 0;
    // for (int i = 0; i < ROW; i++)
    // {
    //     for (int j = 0; j < COL; j++)
    //     {
    //         cout << setw(7) << arr[i][j];
    //         summa += arr[i][j];
    //     }
    //     cout << endl;
    // }
    // const int ROW = 3, COL = 5;
    // int arr[ROW][COL], summa = 0;
    // for (int i = 0; i < ROW; i++)
    // {
    //     for (int j = 0; j < COL; j++)
    //     {
    //         cout << setw(7) << arr[i][j];
    //         summa += arr[i][j];
    //     }
    //     cout << endl;
    // }
    // cout << "Сумма:" << summa << endl;
    const int ROW = 3, COL = 5;
    int arr[ROW][COL], summa = 0, even, index_row, index_col;
    bool exists_even;
    for (int i = 0; i < ROW; i++)
    {
        exists_even = false;
        for (int j = 0; j < COL; j++)
        {
            arr[i][j] = rand() % 41 - 15;
            cout << setw(7) << arr[i][j];
            summa += arr[i][j];
            if (arr[i][j] % 2 == 0)
            {
                even = arr[i][j];
                index_row = i;
                index_col = j;
                exists_even = true;
            }
            
        }
        if(exists_even)
            cout << "\teven = " << even << " i = " << index_row << ", j = " << index_col;
        cout << endl;
    }
    return 0;
}