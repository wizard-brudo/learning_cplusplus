#include <iostream>
using namespace std;

int main()
{
    // Сортировка выбором
    // SelectSort
    // const int N = 10;
    // int numbers[N]{3,5,6,8,4,9,32,675,43246,8}, min, min_index;
    // cout << "Массив до сортировки:";
    // for (int i = 0; i < N; i++)
    // {
    //     cout << numbers[i]  << "    ";
    // }
    // cout << endl;
    // for (int i = 0; i < N; i++)
    // {
    //     min=numbers[i];
    //     min_index=i;
    //     for (int j = i+1; j < N; j++)
    //     {
    //         if (numbers[j] < min) {
    //             min=numbers[j];
    //             min_index=j;
    //         }
    //     }
    //     numbers[min_index] = numbers[i];
    //     numbers[i]=min;
    // }
    // cout << "Массив после сортировки:";
    // for (int i = 0; i < N; i++)
    // {
    //     cout << numbers[i] << "    ";
    // }
    // Сортировка методом пузырька
    // BubbleSort
    // const int N = 10;
    // int numbers[N]{3,5,6,8,4,9,32,675,43246,8}, temp;
    // cout << "Массив до сортировки:";
    // for (int i = 0; i < N; i++)
    // {
    //     cout << numbers[i]  << "    ";
    // }
    // cout << endl;
    // // Сортировка
    // for (int i = 0; i < N-1; i++) // i - номер текущего шага
    // {
    //     for (int j = 0; j < N-1; j++) // j - индекс текущего элемента массива j < N-1 !!! Иначе выход за пределы массива
    //     {
    //         if(numbers[j] > numbers[j + 1]) {
    //             temp = numbers[j];
    //             numbers[j] = numbers[j + 1];
    //             numbers[j+1] = temp;
    //         }
    //     }

    // }

    // cout << "Массив после сортировки:";
    // for (int i = 0; i < N; i++)
    // {
    //     cout << numbers[i] << "    ";
    // }
    // BubbleSort + оптимизации
    // const int N = 10;
    // int numbers[N]{3,5,6,8,4,9,32,675,43246,8}, temp;
    // bool sort_step;
    // cout << "Массив до сортировки:";
    // for (int i = 0; i < N; i++)
    // {
    //     cout << numbers[i]  << "    ";
    // }
    // cout << endl;
    // // Сортировка
    // for (int i = 0; i < N-1; i++) // i - номер текущего шага
    // {
    //     sort_step = false; // Пусть обменов нет
    //     // for (int j = 0; j < N - 1 - i; j++) // j - индекс текущего элемента массива j < N-1 !!! Иначе выход за пределы массива
    //     // {
    //     //     if(numbers[j] > numbers[j + 1]) {
    //     //         temp = numbers[j];
    //     //         numbers[j] = numbers[j + 1];
    //     //         numbers[j+1] = temp;
    //     //         sort_step = true; // Обмен состоялся
    //     //     }
    //     // }
    //     for (int j = N-1; j > i; j--)
    //     {
    //         if(numbers[j - 1] > numbers[j]) {
    //             temp = numbers[j - 1];
    //             numbers[j - 1] = numbers[j];
    //             numbers[j] = temp;
    //             sort_step = true;
    //         }
    //     }

    //     if(!sort_step) // Если обмен не состолся
    //         break; // Выходим
    // }

    // cout << "Массив после сортировки:";
    // for (int i = 0; i < N; i++)
    // {
    //     cout << numbers[i] << "    ";
    // }
    srand(time(0));
    const int N = 10;
    int arr[N], t, range_start, range_finish, temp;
    for (int i = 0; i < N; i++)
    {
        arr[i] = rand() % 21 - 10;
        cout << arr[i] << "     ";
    }
    cout << endl;
    cout << "Введите границы для сортировки:";
    cin >> range_start >> range_finish;
    for (int i = 0; i < range_finish-1; i++)
    {

        for (int j = range_start - 1; j < range_finish - 1 - i; j++) // j - индекс текущего элемента массива j < N-1 !!! Иначе выход за пределы массива
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    cout << "После сортировки:" << endl;
    for (int i = 0; i < N; i++)
    {
        cout << arr[i] << "     ";
    }
    return 0;
}