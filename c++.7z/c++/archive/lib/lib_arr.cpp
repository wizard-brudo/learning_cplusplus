#include "lib_arr.h"
#include "lib.h"
#include <iostream>
#include <iomanip>
using namespace std;
void fill_this(int matrix[][COL],const int ROW, int a, int b) {
    srand(time(0));
    for (int i = 0; i < ROW; i++)
    {
        for (int j = 0; j < COL; j++)
        {
            matrix[i][j] = rand() % (b-a+1)+a;
        }
    }
}

void fill_this(int arr[],const int SIZE, int a, int b) {
    srand(time(0));
    for (int i = 0; i < SIZE; i++)
    {
        arr[i] = rand() % (b-a+1)+a;
    }
}


void show(int matrix[][COL],const int ROW) {
    for (int i = 0; i < ROW; i++)
    {
        for (int j = 0; j < COL; j++)
        {
            cout << setw(6) << matrix[i][j];
        }
        cout << endl;
    }
}
void sort(int arr[], int SIZE, bool direction)
{
    int element, element_index;
    for (int i = 0; i < SIZE; i++)
    {
        element = arr[i];
        element_index = i;
        for (int j = i + 1; j < SIZE; j++)
        {
            if (direction)
            {
                if (arr[j] < element)
                {
                    element = arr[j];
                    element_index = j;
                }
            } else {
                if (arr[j] > element)
                {
                    element = arr[j];
                    element_index = j;
                }
            }
        }
        arr[element_index] = arr[i];
        arr[i] = element;
    }
}

bool is_palindrom(int arr[], const int SIZE)
{
    for (int i = 0; i < SIZE; i++)
    {
        if (arr[i] != arr[SIZE - i - 1])
            return false;
    }
    return true;
}

bool repeations(int arr[], int SIZE, int disered_number)
{
    int count = 0;
    for (int i = 0; i < SIZE; i++)
    {
        if (arr[i] == disered_number)
            count++;
    }
    return count;
}

bool find(int arr[], int SIZE, int disered_number)
{
    for (int i = 0; i < SIZE; i++)
    {
        if (arr[i] == disered_number)
            return true;
    }
    return false;
}

int find_index(int arr[], int SIZE, int disered_number)
{
    for (int i = 0; i < SIZE; i++)
    {
        if (arr[i] == disered_number)
            return i;
    }
    return -1;
}

double average(int numbers[], int SIZE)
{
    double summa = 0;
    for (int i = 0; i < SIZE; i++)
    {
        summa += numbers[i];
    }
    return summa / SIZE;
}

void show(int arr[], int SIZE, bool direction)
{
    if (direction)
    {
        for (int i = 0; i < SIZE; i++)
        {
            cout << arr[i] << " ";
        }
    }
    else
    {
        for (int i = SIZE - 1; i >= 0; i--)
        {
            cout << arr[i] << " ";
        }
    }
}

int get_min(int arr[], const int SIZE)
{
    int min = arr[0];
    for (int i = 0; i < SIZE; i++)
    {
        if (arr[i] < min)
            min = arr[i];
    }
    return min;
}

int get_min(int matrix[][COL], const int ROW)
{
    int min = matrix[0][0];
    for (int i = 0; i < ROW; i++)
    {
        for (int j = 0; j < COL; j++)
        {
            if (matrix[i][j] < min)
                min = matrix[i][j];
        }
    }
    return min;
}

int amount_perfect_numbers(int numbers[],const int SIZE) {
    int count = 0;
    for (int i = 0; i < SIZE; i++)
    {
        if(is_perfect_number(numbers[i]))
            count++;
    }
    return count;
}
int amount_perfect_numbers(int matrix[][COL],const int ROW) {
    int count = 0;
    for (int i = 0; i < ROW; i++)
    {
        for (int j = 0; j < COL; j++)
        {
            if(is_perfect_number(matrix[i][j]))
                count++;
        }
        
    }
    return count;
}

int summa(int arr[],const int SIZE) {
    int summa = 0;
    for (int i = 0; i < SIZE; i++)
    {
        summa += arr[i];
    }
    return summa; 
}

void reverse(int arr[], const int SIZE) {
    int temp;
    for (int i = 0, j = SIZE - 1; i < j; i++, j--)
    {
        temp = arr[j];
        arr[j] = arr[i];
        arr[i] = temp;
    }
}

void wrapper_show(int arr[], const int SIZE) {
    cout << "Массив:";
    show(arr,SIZE);
    cout << endl;
}

void wrapper_show(int matrix[][COL], const int ROW) {
    cout << "Матрица:";
    cout << endl;
    show(matrix,ROW);
    cout << endl;
}

