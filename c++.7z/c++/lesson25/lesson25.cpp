#include <iostream>
#include "../mystl/include/templates.h"
#include "../mystl/include/lib_arr.h"
// #define SUMMA(X,Y) (X+Y)
// #define MAX(X,Y) ((X) > (Y)?(X):(Y))
// #define SQUARE(X) ((X)*(X))
// #define CHISLO int
using namespace std;



int main() {
    // line();
    // line('-');
    // line('-',15);
    // cout << summa(5,5) << endl;
    // cout << SUMMA(5,6) << endl;
    // cout << SQUARE(2+3) << endl;
    // cout << MAX(1,2) << endl;
    const int N = 5,ROW = 5;

    int i[N]{1,2,3,4,5},matrix[ROW][COL];
    fill_it(matrix,ROW);
    show(matrix,ROW);
    cout << maximum(matrix,ROW) << endl;
    return 0;
}